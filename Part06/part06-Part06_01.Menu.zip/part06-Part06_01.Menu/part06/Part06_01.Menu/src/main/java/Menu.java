
import java.util.ArrayList;

public class Menu {

    private ArrayList<String> meals;

    public Menu() {
        this.meals = new ArrayList<>();
    }

    public void addMeal(String string) {
        if(!meals.contains(string)){
            meals.add(string);
        }
    }

    public void printMeals() {
        for(String str : meals){
            System.out.println(str);
        }
    }

    public void clearMenu() {
        meals.clear();
    }
}
