"characters");
        System.out.println(j);        