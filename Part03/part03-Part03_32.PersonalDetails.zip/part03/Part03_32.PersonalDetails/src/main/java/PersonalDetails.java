
import java.util.ArrayList;
import java.util.Scanner;

public class PersonalDetails {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        String output="";
        int sum=0;
        int max=-1;
        int count=0;

        while (true) {
            input = scanner.nextLine();
            if (input.isEmpty()) {
                break;
            }

            String[] arr= input.split(",");
            String s= arr[0];
            
            sum += Integer.valueOf(arr[1]);
            count++;
            
            if(s.length()> max){
                max= s.length();
                output= s;
            }
        }

        System.out.println("Longest name: " + output);
        System.out.println("Average of the birth years: "+ (1.0*sum/count));

    }
}
