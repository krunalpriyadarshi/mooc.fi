
import java.util.Scanner;

public class LastWords {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        while (true) {
            input = scanner.nextLine();
            if (input.isEmpty()) {
                break;
            }
            String[] arr= input.split(" ");
            System.out.println(arr[arr.length-1]);
        }

    }
}