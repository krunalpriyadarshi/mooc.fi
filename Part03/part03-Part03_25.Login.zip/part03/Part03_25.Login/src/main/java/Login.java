
import java.util.ArrayList;
import java.util.Scanner;

public class Login {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter username: ");
        String un= scanner.nextLine();
        System.out.print("Enter password: ");
        String p= scanner.nextLine();


        if((un.equals("alex") && p.equals("sunshine")) || (un.equals("emma") && p.equals("haskell")) ){
            System.out.print("You have successfully logged in!");
        }
        else{
            System.out.println("Incorrect username or password!");
        }
    }

    
}
