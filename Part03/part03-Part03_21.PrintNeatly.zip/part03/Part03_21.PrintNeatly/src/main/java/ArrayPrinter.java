
public class ArrayPrinter {

   
    public static void main(String[] args) {
        // You can test your method here
        int[] array = {5, 1, 3, 4, 2};
        printNeatly(array);
    }

    public static void printNeatly(int[] arr) {
        // Write some code in here
        for(int i=0; i< arr.length-1 ; i++){
            System.out.print(arr[i]+", ");
        }
        System.out.println(arr[arr.length-1]);
    }
}
