
import java.util.Scanner;

public class AVClub {

  
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        while (true) {
            input = scanner.nextLine();
            if (input.isEmpty()) {
                break;
            }
            for (String s : input.split(" ")) {
                if (s.contains("av")) {
                    System.out.println(s);
                }
            }
        }

    }
}
