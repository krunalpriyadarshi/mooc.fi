
import java.util.Scanner;

public class AgeOfTheOldest {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        int max=-1;
        while (true) {
            input = scanner.nextLine();
            if (input.isEmpty()) {
                break;
            }
            int num= Integer.valueOf(input.split(",")[1]);
            if(num> max){
                max= num;
            }
        }
        System.out.println("Age of the oldest: "+max);

    }
}
