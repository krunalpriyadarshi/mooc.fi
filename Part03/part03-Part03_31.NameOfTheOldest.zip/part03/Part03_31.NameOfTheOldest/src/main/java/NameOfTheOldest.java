
import java.util.Scanner;

public class NameOfTheOldest {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        String output="";
        int max=-1;

        while (true) {
            input = scanner.nextLine();
            if (input.isEmpty()) {
                break;
            }

            String[] arr= input.split(",");
            int num= Integer.valueOf(arr[1]);
            if(num> max){
                max= num;
                output= arr[0];
            }
        }

        System.out.println("Name of the oldest: " + output);

    }
}
