public class Film {
    // variables name (String) and ageRating (int).
    private String name;
    private int ageRating;

    public Film(String filmName, int filmAgeRating){
        this.name = filmName;
        this.ageRating = filmAgeRating;
    }

    // public String name() and public int ageRating(). The first of these returns the film title and the second returns its rating.

    public String name(){
        return this.name;
    }

    public int ageRating(){
        return this.ageRating;
    }
}
