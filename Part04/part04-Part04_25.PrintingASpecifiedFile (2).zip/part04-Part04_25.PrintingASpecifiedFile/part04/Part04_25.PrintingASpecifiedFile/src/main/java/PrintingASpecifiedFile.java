
import java.nio.file.Paths;
import java.util.Scanner;

public class PrintingASpecifiedFile {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Which file should have its contents printed?");
        String name =  scanner.nextLine();
        scanner.close();

        try{
            Scanner sc= new Scanner(Paths.get(name));
            while(sc.hasNextLine()){
                name = sc.nextLine();
                System.out.println(name);
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }

    }
}
