
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class RecordsFromAFile {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Name of the file:");
        String file = scanner.nextLine();

        try{
               Scanner sc = new Scanner(Paths.get(file));

                while(sc.hasNextLine()){
                    String s = sc.nextLine();

                    String[] arr = s.split(",");
                    System.out.print(arr[0]);

                    System.out.println((arr[1].equals("1")) ? ", age "+ arr[1]+" year" : ", age "+ arr[1]+" years" );
                }         


        }
        catch(Exception e){
            System.out.println(e);
        }
        
    }
}
