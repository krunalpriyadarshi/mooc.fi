

public class YourFirstAccount {

    public static void main(String[] args) {
        // Do not touch the code in Account.java
        // Write your program here
        Account newEntry= new Account("Krunal", 100);
        newEntry.deposit(20);
        System.out.println(newEntry);
    }
}
