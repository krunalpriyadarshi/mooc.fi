
import java.nio.file.Paths;
import java.util.Scanner;

public class PrintingAFile {

    public static void main(String[] args) {
        try{
            Scanner sc= new Scanner(Paths.get("data.txt"));
            String s;
            while(sc.hasNextLine()){
                s = sc.nextLine();
                System.out.println(s);
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }

    }
}
