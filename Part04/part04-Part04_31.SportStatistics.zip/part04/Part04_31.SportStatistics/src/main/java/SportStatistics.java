
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class SportStatistics {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("File:");
        String file = scan.nextLine();

        System.out.println("Team:");
        String team = scan.nextLine();

        try {

            Scanner sc = new Scanner(Paths.get(file));

            while (scan.hasNextLine()) {
                
            }

        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e);
        }

    }

}
