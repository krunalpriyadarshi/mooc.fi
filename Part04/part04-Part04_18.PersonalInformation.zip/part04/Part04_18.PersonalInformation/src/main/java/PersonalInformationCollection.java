
import java.util.ArrayList;
import java.util.Scanner;

public class PersonalInformationCollection {

    public static void main(String[] args) {
        // implement here your program that uses the PersonalInformation class

        ArrayList<PersonalInformation> infoCollection = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        // First name: Jean
        // Last name: Bartik
        // Identification number: 271224
        String fn, ln, num;
        while(true){
            System.out.print("First name: ");
            fn = sc.nextLine();
            
            if(fn.isEmpty()){
                break;
            }
            
            System.out.print("Last name: ");
            ln = sc.nextLine();
            System.out.print("Identification number: ");
            num = sc.nextLine();


            PersonalInformation pi= new PersonalInformation(fn, ln, num);
            infoCollection.add(pi);
        }
        sc.close();
        System.out.println("");
        for(PersonalInformation pi: infoCollection){
            System.out.println(pi.getFirstName() + " " + pi.getLastName());
        }

    }
}
