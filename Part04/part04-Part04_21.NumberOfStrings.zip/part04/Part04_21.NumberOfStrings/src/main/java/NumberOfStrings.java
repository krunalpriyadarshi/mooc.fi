
import java.util.Scanner;

public class NumberOfStrings {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s;
        int i = 0;
        while(true){
            s= scanner.nextLine();
            if(s.equals("end")){
                break;
            }
            i += 1;
        }
        System.out.println(i);
    }
}
