import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class SportStatistics {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("File:");
        String file = scan.nextLine();

        System.out.println("Team:");
        String team = scan.nextLine();

        ArrayList<Game> games = getGames(file);

        int win = 0, lose = 0;

        for (Game g : games) {
            int result = g.didWin(team);

            if (result > 0) {
                win += 1;
            } else if (result < 0) {
                lose += 1;
            }
        }

        System.out.println("Games: " + (win + lose));
        System.out.println("Wins: " + win);
        System.out.println("Losses: " + lose);
    }

    public static ArrayList<Game> getGames(String file) {
        ArrayList<Game> games = new ArrayList<>();
        try {
            Scanner sc = new Scanner(Paths.get(file));

            while (sc.hasNextLine()) {
                String[] arr = sc.nextLine().split(",");
                games.add(new Game(arr[0], arr[1], Integer.valueOf(arr[2]), Integer.valueOf(arr[3])));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        return games;
    }
}

class Game {
    private String team1, team2;
    private int score1, score2;

    Game(String team1, String team2, int score1, int score2) {
        this.team1 = team1;
        this.team2 = team2;
        this.score1 = score1;
        this.score2 = score2;
    }

    public int didWin(String team) {
        if (hasTeam(team)) {
            if (this.team1.equals(team)) {
                return Integer.compare(score1, score2);
            } else {
                return Integer.compare(score2, score1);
            }
        } else {
            return 0;
        }
    }

    public boolean hasTeam(String team) {
        return this.team1.equals(team) || this.team2.equals(team);
    }
}
