public class Dog {
    private String name;
    private String breed;
    private int age;
}
