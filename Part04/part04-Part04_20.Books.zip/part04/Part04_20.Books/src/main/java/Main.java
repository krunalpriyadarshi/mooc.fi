import java.util.ArrayList;
import java.util.Scanner;

class book{
    private String t, p ,y;

    book(String t, String p, String y){
        this.t = t;
        this.p = p;
        this.y = y;
    }

    String getTitle(){
        return t;
    }

    String getAll(){
        return (t + ", " + p + " pages, " + y);
    }
}


public class Main {

    public static void main(String[] args) {
        
        // implement here the program that allows the user to enter 
        // book information and to examine them
        ArrayList<book> books= new ArrayList<book>();

        Scanner sc= new Scanner(System.in);
        String t, p, y;
        while(true){
            System.out.print("Title: ");
            t = sc.nextLine();
            if( t.isEmpty()){
                break;
            }

            System.out.print("Pages: ");
            p = sc.nextLine();

            System.out.print("Publication year: ");
            y = sc.nextLine();

            books.add(new book(t, p ,y));
        }

        System.out.print("What information will be printed? ");
        if(sc.nextLine().equals("everything")){
            for(book b: books){
                System.out.println(b.getAll());
            }
        }
        else{
            for(book b: books){
                System.out.println(b.getTitle());
            }
        }

        sc.close();
    }
}