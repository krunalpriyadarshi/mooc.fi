
import java.util.Scanner;

public class Cubes {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s;
        int i;
        while(true){
            s= scanner.nextLine();
            if(s.equals("end")){
                break;
            }
            i = Integer.valueOf(s);
            System.out.println(i*i*i);
        }
    }
}
