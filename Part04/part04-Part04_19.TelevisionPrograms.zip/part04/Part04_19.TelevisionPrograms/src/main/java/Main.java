import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // implement here your program that uses the TelevisionProgram class

        ArrayList<TelevisionProgram> programs = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        String name;
        int duration;

        while (true) {
            System.out.print("Name: ");
            name = scanner.nextLine();
            if (name.isEmpty()) {
                break;
            }

            System.out.println("Duration: ");
            duration = Integer.valueOf(scanner.nextLine());

            TelevisionProgram tp = new TelevisionProgram(name, duration);
            programs.add(tp);
        }

        System.out.println("Program's maximum duration? ");
        int maxDuration = Integer.valueOf(scanner.nextLine());

        for (TelevisionProgram tp : programs) {
            if (tp.getDuration() <= maxDuration) {
                System.out.println(tp.toString());
                ;
            }
        }

    }
}
