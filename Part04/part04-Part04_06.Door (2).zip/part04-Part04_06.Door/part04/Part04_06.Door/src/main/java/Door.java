public class Door {
    public void knock(){
        System.out.println("Who's there?");
    }
}
