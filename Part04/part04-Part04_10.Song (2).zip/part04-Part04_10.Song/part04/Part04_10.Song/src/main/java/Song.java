public class Song {
    // The song has the instance variables name (string) and length in seconds (integer).
    private String name;
    private int seconds;
    
    public Song(String name, int length){
        this.name = name;
        this.seconds = length;
    }

    public String name(){
        return this.name;
    }

    public int length(){
        return this.seconds;
    }
}
