
public class Song {

    private String artist;
    private String name;
    private int durationInSeconds;

    public Song(String artist, String name, int durationInSeconds) {
        this.artist = artist;
        this.name = name;
        this.durationInSeconds = durationInSeconds;
    }

    public boolean equals( Object s){

        if (this == s){
            return true;
        }
        
        if (!(s instanceof Song)){
            return false;
        }

        Song newS = (Song) s;

        if( this.artist.equals(newS.artist) && this.name.equals(newS.name) && this.durationInSeconds == newS.durationInSeconds ){
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return this.artist + ": " + this.name + " (" + this.durationInSeconds + " s)";
    }


}
