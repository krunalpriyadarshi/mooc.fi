import java.util.ArrayList;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Product> Products = new ArrayList<Product>();

        while(true){
            System.out.println("Identifier? (empty will stop)");
            String identifier = scanner.nextLine();
            if (identifier.equals("")){
                break;
            }

            System.out.println("Name? (empty will stop)");
            String name = scanner.nextLine();
            if (name.equals("")){
                break;
            }

            Product newP = new Product(identifier, name);

            if(!(Products.contains(newP))){
                Products.add(newP);
            }
            
        }

        if(Products.size() > 0){
            System.out.println("==Items==");
        }

        for(Product p : Products){
            System.out.println(p.toString());
        }
    }
}
