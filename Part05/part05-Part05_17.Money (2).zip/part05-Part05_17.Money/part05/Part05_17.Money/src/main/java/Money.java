
public class Money {

    private final int euros;
    private final int cents;

    public Money(int euros, int cents) {

        if (cents > 99) {
            euros = euros + cents / 100;
            cents = cents % 100;
        }

        this.euros = euros;
        this.cents = cents;
    }

    public Money plus(Money money){
       return new Money(euros + money.euros(), cents + money.cents());
    }

    public boolean lessThan(Money m){
        return (euros < m.euros())? true: ((euros == m.euros() && cents < m.cents())? true: false );
    }

    public Money minus(Money deductMoney){
        int temp_euros = euros - deductMoney.euros();
        int temp_cent = cents - deductMoney.cents();
        if(temp_cent < 0){
            temp_euros -= 1;
            temp_cent += 100;
        }

        return (temp_euros >= 0 ) ? new Money(temp_euros, temp_cent) : new Money(0, 0);
    }

    public int euros() {
        return this.euros;
    }

    public int cents() {
        return this.cents;
    }

    public String toString() {
        String zero = "";
        if (this.cents < 10) {
            zero = "0";
        }

        return this.euros + "." + zero + this.cents + "e";
    }
}
