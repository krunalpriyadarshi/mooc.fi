public class Product {
    private String Identifier;
    private String Name;

    public Product(String Identifier, String Name){
        this.Identifier = Identifier;
        this.Name = Name;
    }

    public String getIdentifier(){
        return this.Identifier;
    }

    public String getName(){
        return  this.Name;
    }

    public String toString(){
        return this.Identifier + ": " + this.Name;
    }

    public boolean equals(Object obj){
        if(this == obj){
            return true;
        }

        if(!(obj instanceof Product)){
            return false;
        }

        Product newP = (Product) obj;
        return this.Identifier.equals(newP.getIdentifier());
    }
}
