
public class MainProgram {

    public static void main(String[] args) {
        // Test your counter here
    }
}
