
import java.util.Scanner;

public class AverageOfPositiveNumbers {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
    
        int sum= 0, count= 0, curr;
        do{
            curr= sc.nextInt();
            if(curr> 0){
                sum+= curr;
                count++;
            }
        }
        while(curr!=0);

        System.out.println((sum==0)?"Cannot calculate the average":(1.0* sum/ count));

        sc.close();
    }
}
