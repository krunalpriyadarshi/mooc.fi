
import java.util.Scanner;

public class Cubes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s="";
        int i= 1;
        s= sc.nextLine();
        while(!s.equals("end")){
            i= Integer.parseInt(s);
            i=(int)Math.pow(i, 3);
            System.out.println(i);
            s= sc.nextLine();
        }

        sc.close();
    }
}
